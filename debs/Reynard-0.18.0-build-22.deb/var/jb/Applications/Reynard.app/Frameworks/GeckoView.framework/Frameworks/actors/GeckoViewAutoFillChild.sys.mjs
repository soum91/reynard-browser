/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

import { GeckoViewActorChild } from "resource://gre/modules/GeckoViewActorChild.sys.mjs";
import { GeckoViewUtils } from "resource://gre/modules/GeckoViewUtils.sys.mjs";
import {
  isSafariTextControl,
  looksLikeSafariOneTimeCodeField,
  looksLikeSafariStandaloneLoginField,
} from "resource://gre/modules/FormFieldClassifier.sys.mjs";

const lazy = {};

ChromeUtils.defineESModuleGetters(lazy, {
  FormLikeFactory: "resource://gre/modules/FormLikeFactory.sys.mjs",
  LoginManagerChild: "resource://gre/modules/LoginManagerChild.sys.mjs",
});

export class GeckoViewAutoFillChild extends GeckoViewActorChild {
  constructor() {
    super();

    this._autofillElements = undefined;
    this._autofillInfos = undefined;
  }

  receiveMessage(aMessage) {
    if (aMessage.name == "FillOneTimeCode") {
      return this.fillOneTimeCode(aMessage.data.fieldUuid, aMessage.data.value);
    }
    return null;
  }

  // eslint-disable-next-line complexity
  handleEvent(aEvent) {
    debug`handleEvent: ${aEvent.type}`;
    switch (aEvent.type) {
      case "DOMFormHasPassword": {
        this.addElement(
          lazy.FormLikeFactory.createFromForm(aEvent.composedTarget)
        );
        break;
      }
      case "DOMInputPasswordAdded": {
        const input = aEvent.composedTarget;
        if (!input.form) {
          this.addElement(lazy.FormLikeFactory.createFromField(input));
        }
        break;
      }
      case "focusin": {
        const element = aEvent.composedTarget;
        if (!isSafariTextControl(element)) {
          break;
        }
        const isOneTimeCode = this._isOneTimeCodeField(element);
        if (isOneTimeCode) {
          this._getInfo(element, null, null, null, null, null, true);
          this.onFocus(element);
        } else if (this._autofillInfos?.has(element)) {
          this.onFocus(element);
        } else if (
          this.contentWindow.HTMLInputElement.isInstance(element) &&
          element.type == "password"
        ) {
          // Some document-level FormLikes omit their focused password input.
          this.addElement(
            lazy.FormLikeFactory.createFromField(element),
            null,
            element
          );
        } else if (
          this.contentWindow.HTMLInputElement.isInstance(element) &&
          looksLikeSafariStandaloneLoginField(element)
        ) {
          // Safari positively identified an otherwise untracked login step.
          this.addElement(
            lazy.FormLikeFactory.createFromField(element),
            element
          );
        }
        GeckoViewUtils.waitForPanZoomState(this.contentWindow).finally(() => {
          if (Cu.isDeadWrapper(element)) {
            // Focus element is removed or document is navigated to new page.
            return;
          }
          const focusedElement =
            Services.focus.focusedElement ||
            element.ownerDocument?.activeElement;
          if (element == focusedElement && element.isConnected) {
            if (
              !this._autofillInfos?.has(focusedElement) &&
              ["text", "email"].includes(focusedElement.type)
            ) {
              const formLike =
                lazy.FormLikeFactory.createFromField(focusedElement);
              const loginManagerChild = lazy.LoginManagerChild.forWindow(
                this.contentWindow
              );
              const docState = loginManagerChild.stateForDocument(
                focusedElement.ownerDocument
              );
              const usernameField =
                docState.getUsernameFieldFromUsernameOnlyForm(formLike, {});
              if (usernameField === focusedElement) {
                // Register only text/email fields positively identified by
                // LoginManager as a username-only login step.
                this.addElement(formLike, usernameField);
                return;
              }
            }
            this.onFocus(focusedElement);
          }
        });
        break;
      }
      case "focusout": {
        if (isSafariTextControl(aEvent.composedTarget)) {
          this.onFocus(null);
        }
        break;
      }
      case "pagehide": {
        if (aEvent.target === this.document) {
          this.clearElements(this.browsingContext);
        }
        break;
      }
      case "pageshow": {
        if (aEvent.target === this.document) {
          this.scanDocument(this.document);
        }
        break;
      }
      case "PasswordManager:ShowDoorhanger": {
        const { form: formLike } = aEvent.detail;
        this.commitAutofill(formLike);
        break;
      }
    }
  }

  _isOneTimeCodeField(aElement) {
    if (!looksLikeSafariOneTimeCodeField(aElement)) {
      return false;
    }

    return this._hasEligibleOneTimeCodePrincipal(aElement);
  }

  _hasEligibleOneTimeCodePrincipal(aElement) {
    try {
      const principal = aElement.nodePrincipal;
      if (!principal || principal.isNullPrincipal) {
        return false;
      }
      if (this.browsingContext === this.browsingContext.top) {
        return true;
      }
      const topPrincipal =
        this.browsingContext.top.currentWindowGlobal?.documentPrincipal;
      return (
        !!topPrincipal &&
        !topPrincipal.isNullPrincipal &&
        principal.equals(topPrincipal)
      );
    } catch {
      return false;
    }
  }

  /**
   * Process an auto-fillable form and send the relevant details of the form
   * to Java. Multiple calls within a short time period for the same form are
   * coalesced, so that, e.g., if multiple inputs are added to a form in
   * succession, we will only perform one processing pass. Note that for inputs
   * without forms, FormLikeFactory treats the document as the "form", but
   * there is no difference in how we process them.
   *
   * @param aFormLike A FormLike object produced by FormLikeFactory.
   * @param aUsernameOnlyField Positively identified username-only field.
   * @param aFocusedPasswordField Focused password omitted by the FormLike.
   */
  async addElement(
    aFormLike,
    aUsernameOnlyField = null,
    aFocusedPasswordField = null
  ) {
    debug`Adding auto-fill ${aFormLike.rootElement.tagName}`;

    const window = aFormLike.rootElement.documentGlobal;
    const focusedCredentialField = aFocusedPasswordField || aUsernameOnlyField;
    // Preserve a positively identified focused field that FormLike omitted.
    const elements =
      focusedCredentialField &&
        !aFormLike.elements.includes(focusedCredentialField)
        ? [...aFormLike.elements, focusedCredentialField]
        : aFormLike.elements;
    // Get password field to get better form data via LoginManagerChild.
    let passwordField;
    for (const field of elements) {
      if (
        ChromeUtils.getClassName(field) === "HTMLInputElement" &&
        field.type == "password"
      ) {
        passwordField = field;
        break;
      }
    }

    const loginManagerChild = lazy.LoginManagerChild.forWindow(window);
    const docState = loginManagerChild.stateForDocument(
      aFormLike.ownerDocument
    );
    let usernameField = aUsernameOnlyField;
    let primaryPasswordField = null;
    let oldPasswordField = null;
    if (passwordField) {
      [usernameField, primaryPasswordField, oldPasswordField] =
        docState.getUserNameAndPasswordFields(passwordField);
    }

    const focusedElement = aFormLike.rootElement.ownerDocument.activeElement;
    let sendFocusEvent = aFormLike.rootElement === focusedElement;

    const rootInfo = this._getInfo(
      aFormLike.rootElement,
      null,
      undefined,
      null
    );

    rootInfo.rootUuid = rootInfo.uuid;
    rootInfo.children = elements
      .filter(
        element =>
          element.type != "hidden" &&
          element.getAutocompleteInfo?.()?.fieldName != "one-time-code" &&
          (!usernameField ||
            element.type != "text" ||
            element == usernameField ||
            element.getAutocompleteInfo()?.fieldName == "email" ||
            element.list?.options?.length)
      )
      .map(element => {
        sendFocusEvent |= element === focusedElement;
        return this._getInfo(
          element,
          rootInfo.uuid,
          rootInfo.uuid,
          usernameField,
          primaryPasswordField,
          oldPasswordField
        );
      });
    rootInfo.acceptsLoginCredentials =
      !!aUsernameOnlyField ||
      rootInfo.children.some(
        info =>
          info.credentialRole == "password" ||
          info.credentialRole == "current-password"
      );

    try {
      // We don't await here so that we can send a focus event immediately
      // after this as the app might not know which element is focused.
      const responsePromise = this.sendQuery("Add", {
        node: rootInfo,
      });

      if (sendFocusEvent) {
        // We might have missed sending a focus event for the active element.
        this.onFocus(aFormLike.ownerDocument.activeElement);
      }

      const responses = await responsePromise;
      // `responses` is an object with global IDs as keys.
      debug`Performing auto-fill ${Object.keys(responses)}`;

      const AUTOFILL_STATE = "autofill";

      for (const uuid in responses) {
        const entry =
          this._autofillElements && this._autofillElements.get(uuid);
        const element = entry && entry.get();
        const value = responses[uuid] || "";

        if (
          window.HTMLInputElement.isInstance(element) &&
          !element.disabled &&
          element.parentElement
        ) {
          element.setUserInput(value);
          if (element.value === value) {
            // Add highlighting for autofilled fields.
            element.autofillState = AUTOFILL_STATE;

            // Remove highlighting when the field is changed.
            element.addEventListener(
              "input",
              _ => (element.autofillState = ""),
              { mozSystemGroup: true, once: true }
            );
          }
        } else if (element) {
          warn`Don't know how to auto-fill ${element.tagName}`;
        }
      }
    } catch (error) {
      warn`Cannot perform autofill ${error}`;
    }
  }

  _getInfo(
    aElement,
    aParent,
    aRoot,
    aUsernameField,
    aPrimaryPasswordField,
    aOldPasswordField,
    aIsOneTimeCode = false
  ) {
    if (!this._autofillInfos) {
      this._autofillInfos = new WeakMap();
      this._autofillElements = new Map();
    }

    let info = this._autofillInfos.get(aElement);
    if (info) {
      if (aIsOneTimeCode) {
        info.isOneTimeCode = true;
      }
      return info;
    }

    const window = aElement.documentGlobal;
    const bounds = aElement.getBoundingClientRect();
    const isInputElement = window.HTMLInputElement.isInstance(aElement);

    info = {
      isInputElement,
      uuid: Services.uuid.generateUUID().toString().slice(1, -1), // discard the surrounding curly braces
      parentUuid: aParent,
      rootUuid: aRoot,
      tag: aElement.tagName,
      type: isInputElement ? aElement.type : null,
      value: isInputElement ? aElement.value : null,
      editable:
        isInputElement &&
        [
          "color",
          "date",
          "datetime-local",
          "email",
          "month",
          "number",
          "password",
          "range",
          "search",
          "tel",
          "text",
          "time",
          "url",
          "week",
        ].includes(aElement.type),
      disabled: isInputElement ? aElement.disabled : null,
      attributes: Object.assign(
        {},
        ...Array.from(aElement.attributes)
          .filter(attr => attr.localName !== "value")
          .map(attr => ({ [attr.localName]: attr.value }))
      ),
      origin: aElement.ownerDocument.location.origin,
      autofillhint: "",
      credentialRole: "",
      bounds: {
        left: bounds.left,
        top: bounds.top,
        right: bounds.right,
        bottom: bounds.bottom,
      },
      datalist: [],
    };

    if (aIsOneTimeCode) {
      info.isOneTimeCode = true;
    }

    if (aElement === aUsernameField) {
      info.autofillhint = "username"; // AUTOFILL.HINT.USERNAME
      info.credentialRole = "username";
    } else if (isInputElement) {
      const autocompleteInfo = aElement.getAutocompleteInfo();
      if (autocompleteInfo) {
        const autocompleteAttr = autocompleteInfo.fieldName;
        if (autocompleteAttr == "email") {
          info.type = "email";
        }
        if (autocompleteAttr == "username") {
          info.credentialRole = "username";
        } else if (autocompleteAttr == "new-password") {
          info.credentialRole = "new-password";
        } else if (autocompleteAttr == "current-password") {
          info.credentialRole = "current-password";
        }
      }
      if (!info.credentialRole && aElement === aOldPasswordField) {
        info.credentialRole = "current-password";
      } else if (!info.credentialRole && aElement === aPrimaryPasswordField) {
        info.credentialRole = "password";
      }

      if (aElement.list?.options) {
        debug`${aElement.tagName} has ${aElement.list.options.length} items in datalist`;
        for (const item of aElement.list.options) {
          info.datalist.push(item.value);
        }
      }
    }

    this._autofillInfos.set(aElement, info);
    this._autofillElements.set(info.uuid, Cu.getWeakReference(aElement));
    return info;
  }

  _activeElement(document) {
    let element = document.activeElement;
    while (element?.openOrClosedShadowRoot?.activeElement) {
      element = element.openOrClosedShadowRoot.activeElement;
    }
    return element;
  }

  _isWritableOneTimeCodeField(element) {
    return (
      element?.isConnected &&
      !element.disabled &&
      !element.readOnly &&
      isSafariTextControl(element) &&
      this._isOneTimeCodeField(element)
    );
  }

  _dispatchInputEvent(element, type, inputType, data = null) {
    return element.dispatchEvent(
      new element.documentGlobal.InputEvent(type, {
        bubbles: true,
        cancelable: type == "beforeinput",
        composed: true,
        data,
        inputType,
      })
    );
  }

  _dispatchKeyEvent(element, type, key) {
    let code = "";
    if (/^\d$/.test(key)) {
      code = `Digit${key}`;
    } else if (/^[a-z]$/i.test(key)) {
      code = `Key${key.toUpperCase()}`;
    }
    return element.dispatchEvent(
      new element.documentGlobal.KeyboardEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        key,
        code,
      })
    );
  }

  _clearOneTimeCodeField(element) {
    try {
      element.select();
    } catch { }
    this._dispatchKeyEvent(element, "keydown", "Backspace");
    if (
      this._dispatchInputEvent(element, "beforeinput", "deleteContentBackward")
    ) {
      element.value = "";
      this._dispatchInputEvent(element, "input", "deleteContentBackward");
    }
    this._dispatchKeyEvent(element, "keyup", "Backspace");
    element.dispatchEvent(
      new element.documentGlobal.Event("change", { bubbles: true })
    );
  }

  _insertOneTimeCodeCharacter(element, character) {
    this._dispatchKeyEvent(element, "keydown", character);
    this._dispatchKeyEvent(element, "keypress", character);

    const textInput = element.ownerDocument.createEvent("TextEvent");
    textInput.initTextEvent(
      "textInput",
      true,
      true,
      element.documentGlobal,
      character
    );
    const previousValue = element.value;
    if (
      element.dispatchEvent(textInput) &&
      this._dispatchInputEvent(
        element,
        "beforeinput",
        "insertText",
        character
      ) &&
      element.value == previousValue
    ) {
      const start = element.selectionStart ?? element.value.length;
      const end = element.selectionEnd ?? start;
      element.setRangeText(character, start, end, "end");
      this._dispatchInputEvent(element, "input", "insertText", character);
    }
    this._dispatchKeyEvent(element, "keyup", character);
  }

  _wait(window, milliseconds) {
    return new Promise(resolve => window.setTimeout(resolve, milliseconds));
  }

  async _nextOneTimeCodeField(element) {
    for (let attempt = 0; attempt < 20; attempt++) {
      const focused = this._activeElement(element.ownerDocument);
      if (focused !== element) {
        return this._isWritableOneTimeCodeField(focused) ? focused : null;
      }
      await this._wait(element.documentGlobal, 1);
    }
    return null;
  }

  _oneTimeCodeWasInserted(fields, value) {
    return (
      fields
        .map(field => field.value)
        .join("")
        .replaceAll("-", "") == value.replaceAll("-", "")
    );
  }

  _setOneTimeCodeValue(element, value) {
    if (typeof element.setUserInput == "function") {
      element.setUserInput(value);
      return;
    }
    if (this._dispatchInputEvent(element, "beforeinput", "insertText", value)) {
      element.value = value;
      this._dispatchInputEvent(element, "input", "insertText", value);
      element.dispatchEvent(
        new element.documentGlobal.Event("change", { bubbles: true })
      );
    }
  }

  async fillOneTimeCode(fieldUuid, value) {
    const entry = this._autofillElements?.get(fieldUuid);
    const firstField = entry?.get();
    const info = firstField && this._autofillInfos?.get(firstField);
    if (
      typeof value != "string" ||
      !value ||
      !info?.isOneTimeCode ||
      this._activeElement(firstField?.ownerDocument) !== firstField ||
      !this._isWritableOneTimeCodeField(firstField)
    ) {
      return false;
    }

    if (firstField.maxLength != 1) {
      this._setOneTimeCodeValue(firstField, value);
      return firstField.value == value;
    }

    const interactionEvents = [
      "keydown",
      "keypress",
      "keyup",
      "dblclick",
      "mousedown",
      "mousemove",
      "mouseup",
      "click",
      "pointerdown",
      "pointermove",
      "pointerup",
      "pointercancel",
      "touchstart",
      "touchmove",
      "touchend",
      "touchcancel",
    ];
    const suppressInteraction = event => {
      if (event.isTrusted) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };
    for (const type of interactionEvents) {
      firstField.ownerDocument.addEventListener(
        type,
        suppressInteraction,
        true
      );
    }

    const touchedFields = [];
    let field = firstField;
    try {
      for (let index = 0; index < value.length; index++) {
        const character = value[index];
        if (!this._isWritableOneTimeCodeField(field)) {
          break;
        }
        if (!touchedFields.includes(field)) {
          touchedFields.push(field);
          this._clearOneTimeCodeField(field);
        }
        this._insertOneTimeCodeCharacter(field, character);
        await this._wait(field.documentGlobal, 10);
        field = await this._nextOneTimeCodeField(field);
        if (!field && index + 1 < value.length) {
          break;
        }
      }

      if (!this._oneTimeCodeWasInserted(touchedFields, value)) {
        this._setOneTimeCodeValue(firstField, value);
        touchedFields.splice(0, touchedFields.length, firstField);
      }
      return this._oneTimeCodeWasInserted(touchedFields, value);
    } finally {
      for (const type of interactionEvents) {
        firstField.ownerDocument.removeEventListener(
          type,
          suppressInteraction,
          true
        );
      }
    }
  }

  _updateInfoValues(aElements) {
    if (!this._autofillInfos) {
      return [];
    }

    const updated = [];
    for (const element of aElements) {
      const info = this._autofillInfos.get(element);

      if (!info?.isInputElement || info.value === element.value) {
        continue;
      }
      debug`Updating value ${info.value} to ${element.value}`;

      info.value = element.value;
      this._autofillInfos.set(element, info);
      updated.push(info);
    }
    return updated;
  }

  /**
   * Called when an auto-fillable field is focused or blurred.
   *
   * @param aTarget Focused element, or null if an element has lost focus.
   */
  onFocus(aTarget) {
    debug`Auto-fill focus on ${aTarget && aTarget.tagName}`;

    const info = (() => {
      if (!aTarget) {
        // focus is blur
        return null;
      }
      const targetInfo = this._autofillInfos?.get(aTarget);
      if (targetInfo) {
        return targetInfo;
      }
      if (!aTarget.list) {
        return null;
      }
      // Focused element has datalist.
      if (aTarget.form) {
        this.addElement(lazy.FormLikeFactory.createFromForm(aTarget.form));
      } else {
        this.addElement(lazy.FormLikeFactory.createFromField(aTarget));
      }
      return this._autofillInfos?.get(aTarget);
    })();

    if (info) {
      const win = aTarget.documentGlobal;
      const bounds = aTarget.getBoundingClientRect();
      const screenRect = win.windowUtils.toScreenRect(
        bounds.left,
        bounds.top,
        bounds.width,
        bounds.height
      );
      info.screenRect = {
        left: screenRect.left,
        top: screenRect.top,
        right: screenRect.right,
        bottom: screenRect.bottom,
      };
    }

    if (!aTarget || info) {
      this.sendAsyncMessage("Focus", {
        node: info,
      });
    }
  }

  commitAutofill(aFormLike) {
    if (!aFormLike) {
      throw new Error("null-form on autofill commit");
    }

    debug`Committing auto-fill for ${aFormLike.rootElement.tagName}`;

    const updatedNodeInfos = this._updateInfoValues([
      aFormLike.rootElement,
      ...aFormLike.elements,
    ]);

    for (const updatedInfo of updatedNodeInfos) {
      debug`Updating node ${updatedInfo}`;
      this.sendAsyncMessage("Update", {
        node: updatedInfo,
      });
    }

    const info = this._getInfo(aFormLike.rootElement);
    if (info) {
      debug`Committing node ${info}`;
      this.sendAsyncMessage("Commit", {
        node: info,
      });
    }
  }

  /**
   * Clear all tracked auto-fill forms and notify Java.
   */
  clearElements(browsingContext) {
    this._autofillInfos = undefined;
    this._autofillElements = undefined;

    if (browsingContext === browsingContext.top) {
      this.sendAsyncMessage("Clear");
    }
  }

  /**
   * Scan for auto-fillable forms and add them if necessary. Called when a page
   * is navigated to through history, in which case we don't get our typical
   * "input added" notifications.
   *
   * @param aDoc Document to scan.
   */
  scanDocument(aDoc) {
    // Add forms first; only check forms with password inputs.
    const inputs = aDoc.querySelectorAll("input[type=password]");
    let inputAdded = false;
    for (let i = 0; i < inputs.length; i++) {
      if (inputs[i].form) {
        // Let addElement coalesce multiple calls for the same form.
        this.addElement(lazy.FormLikeFactory.createFromForm(inputs[i].form));
      } else if (!inputAdded) {
        // Treat inputs without forms as one unit, and process them only once.
        inputAdded = true;
        this.addElement(lazy.FormLikeFactory.createFromField(inputs[i]));
      }
    }
  }
}

const { debug, warn } = GeckoViewAutoFillChild.initLogging("GeckoViewAutoFill");
